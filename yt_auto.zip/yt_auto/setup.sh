#!/usr/bin/env bash
# One-time setup. Needs: python3.10+, node/npm, ffmpeg.
set -e
pip install -r requirements.txt
python3 -m playwright install chromium
(cd fonts && npm install)
[ -f .env ] || cp .env.example .env
echo "Now edit .env (API keys) and put your Google OAuth file at client_secret.json"
