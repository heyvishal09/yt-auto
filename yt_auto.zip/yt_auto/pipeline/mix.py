"""Mix voice + SFX bed onto the silent video, limited so it never clips."""
import subprocess


def mix(silent, voice_mp3, bed_wav, dur, out):
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(silent), "-i", str(voice_mp3),
                    "-i", str(bed_wav), "-filter_complex",
                    "[1:a]volume=1.0[v];[2:a]volume=0.75[b];[v][b]amix=inputs=2:normalize=0:duration=longest,alimiter=limit=0.8:level=0[a]",
                    "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-crf", "24", "-c:a", "aac", "-b:a", "160k",
                    "-t", f"{dur:.2f}", "-movflags", "+faststart", str(out)], check=True)
    return out
