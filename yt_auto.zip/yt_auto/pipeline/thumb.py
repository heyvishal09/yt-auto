"""Two thumbnails in the same pixel style: 1280x720 (long) and 1080x1920 (Shorts cover)."""
from pathlib import Path

from playwright.sync_api import sync_playwright

from .render import BG, CREAM, PAL, SPR, font_css

PAGE = """<html><style>{fonts}*{{margin:0}}body{{width:{w}px;height:{h}px;background:{bg};position:relative;overflow:hidden;
font-family:'YA';text-align:center;color:{cream};line-height:1}}div{{position:absolute;left:0;right:{r}px;white-space:nowrap}}svg{{position:absolute;image-rendering:pixelated}}
</style><body><div style="top:{y1}px;font-size:{s}px">{top}</div><div style="top:{y2}px;font-size:{s}px;color:#E8321A">{bottom}</div>{svg}"""

SIZES = {"thumb_long.png": dict(w=1280, h=720, y1=60, y2=330, s=150, sc=34, sx=764, sy=200, r=520),
         "thumb_short.png": dict(w=1080, h=1920, y1=700, y2=980, s=190, sc=30, sx=330, sy=200, r=0)}


def make(thumb, sprite, out_dir):
    out = Path(out_dir)
    g = SPR[sprite or "robot"]
    rects = "".join(f'<rect x="{c}" y="{r}" width="1.02" height="1.02" fill="{PAL[ch]}"/>'
                    for r, row in enumerate(g) for c, ch in enumerate(row) if ch != ".")
    with sync_playwright() as p:
        br = p.chromium.launch()
        for name, d in SIZES.items():
            n = max(len(thumb['top']), len(thumb['bottom']))
            d = {**d, 's': min(d['s'], int((d['w'] - d['r'] - 60) / (0.66 * n)))}
            svg = (f'<svg style="left:{d["sx"]}px;top:{d["sy"]}px" width="{len(g[0]) * d["sc"]}" height="{len(g) * d["sc"]}" '
                   f'viewBox="0 0 {len(g[0])} {len(g)}" shape-rendering="crispEdges">{rects}</svg>')
            f = (out / "_t.html").resolve()
            f.write_text(PAGE.format(fonts=font_css(), bg=BG, cream=CREAM, top=thumb["top"].upper(),
                                     bottom=thumb["bottom"].upper(), svg=svg, **d), encoding="utf-8")
            pg = br.new_page(viewport={"width": d["w"], "height": d["h"]})
            pg.goto("file://" + str(f))
            pg.wait_for_timeout(800)
            pg.screenshot(path=str(out / name))
            pg.close()
        br.close()
    (out / "_t.html").unlink()
