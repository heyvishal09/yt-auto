"""Synthesised 8-bit SFX + quiet chiptune bed timed from the scene list. Pure numpy/scipy."""
import wave
import numpy as np
from scipy.signal import butter, lfilter

SR = 44100
rng = np.random.default_rng(5)


def bp(x, lo, hi):
    b, a = butter(2, [lo / (SR / 2), hi / (SR / 2)], btype="band")
    return lfilter(b, a, x)


def lp(x, f):
    b, a = butter(2, f / (SR / 2))
    return lfilter(b, a, x)


def put(tr, t0, sig, g=1.0):
    i = max(0, int(t0 * SR))
    if i >= len(tr):
        return
    seg = sig[: len(tr) - i]
    tr[i:i + len(seg)] += seg * g


def sq(f, n, duty=0.5):
    t = np.arange(n) / SR
    return np.where((t * f) % 1 < duty, 1.0, -1.0)


def blip(f=880, d=0.07):
    n = int(d * SR)
    t = np.arange(n) / SR
    return sq(f, n, 0.25) * np.exp(-t / (d * 0.5)) * 0.5


def coin():
    a = blip(988, 0.06)
    b = blip(1319, 0.18)
    return np.concatenate([a, b])


def buzz():
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    return lp(sq(110, n), 1500) * np.exp(-t / 0.15) * 0.7


def slam():
    n = int(0.5 * SR)
    t = np.arange(n) / SR
    k = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 9) + 40) / SR) * np.exp(-t / 0.2) * 1.2
    c = bp(rng.standard_normal(n), 800, 5000) * np.exp(-t / 0.03) * 0.8
    return k + c


def glitch():
    n = int(0.28 * SR)
    out = np.zeros(n)
    for k in range(7):
        a = int(k * n / 7)
        b = int((k + 0.7) * n / 7)
        f = rng.choice([180, 420, 900, 1700, 60])
        out[a:b] = sq(f, b - a, 0.5) * 0.35 + rng.standard_normal(b - a) * 0.15
    return out * np.linspace(1, 0.2, n)


def crunch(d=0.32):
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    out = np.zeros(n)
    for k in range(10):
        a = int(rng.uniform(0, 0.8) * n)
        m = int(0.04 * SR)
        seg = bp(rng.standard_normal(m), 600, 7000) * np.exp(-np.arange(m) / SR / 0.012)
        out[a:a + m] += seg[: n - a]
    return out * (1 - 0.3 * t) * 0.9


def key():
    n = int(0.04 * SR)
    t = np.arange(n) / SR
    return (bp(rng.standard_normal(n), 2000, 6000) * np.exp(-t / 0.006) + sq(300, n) * np.exp(-t / 0.01) * 0.3) * 0.7


def whoosh():
    n = int(0.3 * SR)
    t = np.linspace(0, 1, n)
    return bp(rng.standard_normal(n), 400, 6000) * np.sin(np.pi * t) ** 2 * 0.5


def riser(d=1.2):
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    f = 200 + 1600 * t ** 2
    return sq(1, n) * 0 + np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * 0.25 * t ** 2



def norm(x, p):
    return x / (np.max(np.abs(x)) + 1e-9) * p


def save(path, x):
    x = np.clip(x, -1, 1)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())


def make(scenes, wemph, W, DUR, out_path):
    N = int(DUR * SR)
    sfx = np.zeros(N)
    starts = [0.0] + [W[s["a"]][1] - 0.04 for s in scenes[1:]]
    for b in starts[1:]:
        put(sfx, b - 0.2, crunch(), 0.7)
        put(sfx, b - 0.05, whoosh(), 0.5)
    for i, w in enumerate(W):
        put(sfx, w[1], blip([660, 784, 880, 988][i % 4], 0.05), 0.2)
    for i, kind in wemph.items():
        i = int(i)
        if kind == "slam":
            put(sfx, W[i][1] - 0.02, slam(), 0.85)
        elif kind == "glitch":
            put(sfx, W[i][1], glitch(), 0.7)
        else:
            put(sfx, W[i][1], coin(), 0.45)
    for s in scenes:
        a, b, ty = s["a"], s["b"], s["type"]
        if ty == "chat":
            for i in range(a, b + 1):
                put(sfx, W[i][1], key(), 0.5)
            if "counter" in s:
                c = s["counter"]
                t1, t2 = W[c["from"]][1], W[c["to"]][1]
                for k in range(c["max"]):
                    put(sfx, t1 + k * max(t2 - t1, 0.1) / c["max"], blip(520 + k * 70, 0.05), 0.45)
        if ty == "tiles":
            t0 = W[a][1] - 0.04 + 0.1
            for k in range(10):
                put(sfx, t0 + k * 0.3, blip(700 + 40 * k, 0.06), 0.45)
            put(sfx, W[s["tiles"]["bad"]][1], buzz(), 0.6)
        if ty == "rounds":
            for i in s["rounds"]["at"]:
                put(sfx, W[i][1], coin(), 0.5)
            put(sfx, W[s["rounds"]["done"]][1], coin(), 0.8)
        if ty == "cta":
            tp = W[b - min(2, b - a)][1]
            for k in range(len(s.get("keyword", "TOPIC"))):
                put(sfx, tp + k * 0.12, key(), 0.6)
            put(sfx, W[a][1] - 0.9, riser(0.9), 0.4)
    # quiet chiptune-ish bed: square arpeggio, 96 bpm
    bed = np.zeros(N)
    beat = 60 / 96
    arp = [220.0, 261.6, 329.6, 440.0, 329.6, 261.6]
    roots = [110.0, 87.3, 98.0, 82.4]
    t = 0.0
    k = 0
    while t < DUR:
        f = arp[k % 6] * (0.8 if (k // 12) % 2 else 1.0)
        n = int(0.16 * SR)
        put(bed, t, sq(f, n, 0.25) * np.exp(-np.arange(n) / SR / 0.07) * 0.3, 1)
        if k % 8 == 0:
            nb = int(beat * 2 * SR)
            tb = np.arange(nb) / SR
            put(bed, t, np.sign(np.sin(2 * np.pi * roots[(k // 8) % 4] * tb)) * np.exp(-tb / 0.6) * 0.35, 1)
        if k % 4 == 0:
            nn = int(0.2 * SR)
            tt = np.arange(nn) / SR
            put(bed, t, np.sin(2 * np.pi * np.cumsum(110 * np.exp(-tt * 20) + 45) / SR) * np.exp(-tt / 0.08) * 0.8, 1)
        t += beat / 2
        k += 1
    bed = lp(bed, 5000)
    bed *= np.minimum(np.arange(N) / SR / 0.4, 1) * np.minimum((DUR - np.arange(N) / SR) / 0.8, 1)


    sfx = norm(sfx, 0.8)
    save(out_path, norm(sfx * 0.9 + norm(bed, 0.8) * 0.14, 0.85))
    return out_path
