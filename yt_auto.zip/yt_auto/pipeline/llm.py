"""Step 1: topic -> script + scene spec + upload metadata, via the Anthropic Messages API."""
import json
import os
import re

import requests

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")

SYSTEM = """You write 25-32 second YouTube Shorts for an English AI-and-study-skills channel.
Hook in the first 3 seconds (a claim that contradicts what viewers believe). One idea. Concrete. No filler.
Spoken script: 62-80 words, plain spoken English, ends with a call to comment a keyword.
You also split the script into SCENES that drive an animation. Reply with ONLY one JSON object."""

SCHEMA = """{
 "title": "<=60 chars, curiosity, no clickbait lies",
 "description": "2-3 sentences + the copy-paste prompt if the video teaches one + 3-5 hashtags incl #Shorts",
 "tags": ["8-12 search tags"],
 "thumb": {"top": "1-2 words", "bottom": "1-3 words, must not repeat the title"},
 "script": "the full spoken script",
 "scenes": [
  {"type": "kinetic|chat|tiles|rounds|cta",
   "text": "the exact consecutive words of the script for this scene (all scenes joined == script)",
   "sprite": "book|robot|warn|heart (optional; not for chat)",
   "emph": [[word_index_in_scene, "red|orange|teal|amber", "slam|glitch|pop"]],
   "strike": {"word": idx, "at": idx},            // optional: strike a word through when 'at' is spoken
   "counter": {"label": "GAPS FOUND", "from": idx, "to": idx, "max": 7},   // chat only, optional
   "tiles": {"bad_at": idx, "bad_idx": 5},          // tiles only: one tile turns red/'?' at that word
   "rounds": {"at": [i, j, k], "done": m},          // rounds only: three ROUND tiles light at words i,j,k then all turn teal at m
   "keyword": "TOPIC"                               // cta only: word typed into the comment box
  }]
}
Rules: first scene = hook (kinetic, with a slam/glitch emphasis). Use exactly one chat scene if the video shows a prompt
for the viewer to give AI (put the quoted prompt words in it). Use 'tiles' for "find your weak spots / wrong answers" beats,
'rounds' for a 3-step/3-round beat, last scene = cta. 5-8 scenes. Indices are 0-based inside each scene's text.
Max 2 emphasised words per scene. Teal is for tech words (AI, prompt). Red for danger/wrong, orange for the payoff word."""


def _extract_json(txt):
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        raise ValueError("no JSON in model reply")
    return json.loads(m.group(0))


def validate(spec):
    words = spec["script"].split()
    joined = " ".join(s["text"] for s in spec["scenes"]).split()
    if [w.lower() for w in words] != [w.lower() for w in joined]:
        raise ValueError("scene texts do not add up to the script")
    if not 40 <= len(words) <= 100:
        raise ValueError(f"script length {len(words)} words out of range")
    for s in spec["scenes"]:
        if s.get("type") not in ("kinetic", "chat", "tiles", "rounds", "cta"):
            raise ValueError("bad scene type")
        n = len(s["text"].split())
        for e in s.get("emph", []):
            if not 0 <= e[0] < n:
                raise ValueError("emph index out of range")
    if len(spec["title"]) > 70:
        spec["title"] = spec["title"][:67] + "..."
    return spec


def make_spec(topic, extra=""):
    key = os.environ["ANTHROPIC_API_KEY"]
    prompt = f"Topic: {topic}\n{extra}\n\nReturn JSON in this shape:\n{SCHEMA}"
    last = None
    for attempt in range(3):
        r = requests.post("https://api.anthropic.com/v1/messages",
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                          json={"model": MODEL, "max_tokens": 3000, "system": SYSTEM,
                                "messages": [{"role": "user", "content": prompt + (f"\n\nFix this problem from your last try: {last}" if last else "")}]},
                          timeout=120)
        r.raise_for_status()
        txt = "".join(b.get("text", "") for b in r.json()["content"])
        try:
            return validate(_extract_json(txt))
        except Exception as e:  # retry with the error message
            last = str(e)
    raise RuntimeError(f"LLM spec failed validation 3 times: {last}")
