"""Step 2-3: ElevenLabs text-to-speech (your cloned voice) + word-level timestamps, then align to the script."""
import difflib
import os
import re
from pathlib import Path

import requests

API = "https://api.elevenlabs.io/v1"


def tts(text, out_mp3, voice_id=None, model="eleven_multilingual_v2"):
    voice_id = voice_id or os.environ["ELEVENLABS_VOICE_ID"]
    r = requests.post(f"{API}/text-to-speech/{voice_id}?output_format=mp3_44100_128",
                      headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"]},
                      json={"text": text, "model_id": model,
                            "voice_settings": {"stability": 0.45, "similarity_boost": 0.85, "style": 0.2}}, timeout=180)
    r.raise_for_status()
    Path(out_mp3).write_bytes(r.content)
    return out_mp3


def transcribe(mp3):
    with open(mp3, "rb") as f:
        r = requests.post(f"{API}/speech-to-text", headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"]},
                          data={"model_id": "scribe_v1", "timestamps_granularity": "word", "language_code": "en"},
                          files={"file": f}, timeout=300)
    r.raise_for_status()
    return [w for w in r.json()["words"] if w.get("type") == "word"]


def _n(w):
    return re.sub(r"[^a-z0-9']", "", w.lower())


def align(script, stt_words):
    """Return [[word, start, end]] with exactly one entry per script word (robust to tokenisation differences)."""
    sw = script.split()
    a = [_n(w) for w in sw]
    b = [_n(w["text"]) for w in stt_words]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    t = [None] * len(sw)
    for i, j, n in sm.get_matching_blocks():
        for k in range(n):
            t[i + k] = (stt_words[j + k]["start"], stt_words[j + k]["end"])
    # interpolate unmatched words between known neighbours
    known = [i for i, v in enumerate(t) if v]
    if not known:
        raise RuntimeError("could not align transcript to script")
    for i in range(len(sw)):
        if t[i]:
            continue
        lo = max([k for k in known if k < i], default=None)
        hi = min([k for k in known if k > i], default=None)
        if lo is None:
            t[i] = (0.0, t[hi][0])
        elif hi is None:
            t[i] = (t[lo][1], t[lo][1] + 0.3)
        else:
            gap = hi - lo
            s0, s1 = t[lo][1], t[hi][0]
            t[i] = (s0 + (s1 - s0) * (i - lo) / gap, s0 + (s1 - s0) * (i - lo + 0.8) / gap)
    return [[sw[i].strip('"'), round(t[i][0], 3), round(t[i][1], 3)] for i in range(len(sw))]
