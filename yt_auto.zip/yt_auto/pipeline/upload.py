"""Step 8: upload to YOUR channel via the YouTube Data API. First run opens a browser once; the token is cached."""
import os
import pickle
from pathlib import Path

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


def _creds(client_secret, token_file):
    creds = None
    if Path(token_file).exists():
        creds = pickle.loads(Path(token_file).read_bytes())
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            creds = InstalledAppFlow.from_client_secrets_file(client_secret, SCOPES).run_local_server(port=0)
        Path(token_file).write_bytes(pickle.dumps(creds))
    return creds


def upload(video, meta, privacy="private", publish_at=None, synthetic=True,
           client_secret=None, token_file="token.pickle"):
    client_secret = client_secret or os.environ.get("YT_CLIENT_SECRET", "client_secret.json")
    yt = build("youtube", "v3", credentials=_creds(client_secret, token_file))
    title = meta["title"]
    if "#shorts" not in title.lower() and "#shorts" not in meta["description"].lower():
        meta["description"] += "\n\n#Shorts"
    status = {"privacyStatus": "private" if publish_at else privacy, "selfDeclaredMadeForKids": False,
              "containsSyntheticMedia": synthetic}
    if publish_at:
        status["publishAt"] = publish_at  # RFC3339, e.g. 2026-10-20T14:30:00Z
    body = {"snippet": {"title": title, "description": meta["description"], "tags": meta["tags"], "categoryId": "27"},
            "status": status}
    req = yt.videos().insert(part="snippet,status", body=body,
                             media_body=MediaFileUpload(str(video), chunksize=-1, resumable=True))
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    return f"https://youtube.com/shorts/{resp['id']}"
