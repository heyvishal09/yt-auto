"""Generic scene renderer: scene spec + word timings -> silent 1080x1920 mp4.
One HTML page, drawn per frame by JS (draw(t)), screenshotted by Playwright, encoded by ffmpeg.

Scene types: kinetic | chat | tiles | rounds | cta
Everything visual is original pixel art + CSS; fonts come from @fontsource (latin)."""
import json
import re
import shutil
import subprocess
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
FONT_DIR = ROOT / "fonts" / "node_modules" / "@fontsource"
FPS = 30

BG, DARK, GREY, CRIM, ORG, AMB, CREAM, TEAL, TEAL2 = ("#060403", "#27100A", "#3E3C39", "#B3200F", "#DE581D",
                                                    "#E3AA53", "#D9D1C5", "#4EC5C4", "#1C828A")
COL = {"red": "#E8321A", "orange": ORG, "teal": TEAL, "amber": AMB, "cream": CREAM}
FAM = {"pp": "'PP'", "kh": "'KH'", "ya": "'YA'", "ro": "'RO'", "mu": "'MU'", "jb": "'JB'"}
FONT_FILES = [("PP", "poppins", 800), ("KH", "khand", 700), ("YA", "yatra-one", 400), ("RO", "rozha-one", 400),
              ("MU", "mukta", 800), ("JB", "jetbrains-mono", 800)]

PAL = {"o": ORG, "d": "#801106", "c": CREAM, "t": TEAL, "T": TEAL2, "k": "#0d0806", "r": "#E8321A", "a": AMB,
       "g": GREY, "y": "#F4C95D"}
SPR = {
    "robot": ["......rr......", "......dd......", "..oooooooooo..", ".oooooooooooo.", ".ookkkookkkoo.", ".ookttkokttoo.",
              ".ookkkookkkoo.", ".oooooooooooo.", ".oodddddddddo.", ".oooooooooooo.", "..dddddddddd..",
              "ddoooooooooodd", "dd.oo....oo.dd", "...dd....dd..."],
    "book": ["..dddddddddd..", ".dooooooooood.", ".dooooooooood.", ".dooccccccood.", ".dooooooooood.", ".dooccccccood.",
             ".dooooooooood.", ".dooccccoooood", ".dooooooooood.", ".dooooooooood.", ".dooooooooood.",
             ".dooooooooood.", ".dddddddddddd.", "..cccccccccc.."],
    "warn": [".......aa.......", "......aaaa......", "......aaaa......", ".....aakkaa.....", ".....aakkaa.....",
             "....aaakkaaa....", "....aaakkaaa....", "...aaaakkaaaa...", "...aaaaaaaaaa...", "..aaaaakkaaaaa..",
             "..aaaaakkaaaaa..", ".aaaaaaaaaaaaaa.", "aaaaaaaaaaaaaaaa"],
    "heart": [".rrr...rrr.", "rrrrr.rrrrr", "rrrrrrrrrrr", "rrrrrrrrrrr", ".rrrrrrrrr.", "..rrrrrrr..", "...rrrrr...",
              "....rrr....", ".....r....."],
    "cursor": ["c.........", "cc........", "ccc.......", "cccc......", "ccccc.....", "cccccc....", "ccccccc...",
               "cccc......", "cc.cc.....", "c..cc.....", "....cc...."],
}
SPRITE_SCALE = {"robot": 34, "book": 30, "warn": 28, "heart": 30}
FONTSEQ = ["pp", "kh", "ya", "ro", "mu"]


def norm(w):
    return re.sub(r"[^a-z0-9']", "", w.lower())


def make_lines(idx_words):
    """idx_words: [(global_idx, text)] -> list of (idx_list, size)."""
    lines, cur, chars = [], [], 0
    for gi, w in idx_words:
        if cur and (len(cur) >= 4 or chars + len(w) > 20):
            lines.append(cur)
            cur, chars = [], 0
        cur.append((gi, w))
        chars += len(w) + 1
        if re.search(r"[.!?:]$", w) or (re.search(r",$", w) and len(cur) >= 2):
            lines.append(cur)
            cur, chars = [], 0
    if cur:
        lines.append(cur)
    out = []
    for ln in lines:
        c = sum(len(w) for _, w in ln) + len(ln) - 1
        size = 230 if c <= 8 else 170 if c <= 14 else 130 if c <= 20 else 110
        out.append(([g for g, _ in ln], size))
    return out


def prepare(scenes_spec, words):
    """Turn LLM scene spec (relative word offsets) into absolute indexed scenes for the page."""
    scenes, wstyle, wemph = [], {}, {}
    for i, w in enumerate(words):
        wstyle[i] = [FONTSEQ[(i * 3 + i // 4) % 5], CREAM]
    pos = 0
    for sc in scenes_spec:
        n = len(sc["text"].split())
        a, b = pos, pos + n - 1
        pos += n
        for item in sc.get("emph", []):
            rel, color, anim = item[0], item[1], (item[2] if len(item) > 2 else "pop")
            gi = a + rel
            if gi > b:
                continue
            wstyle[gi] = ["jb" if color == "teal" and words[gi][0].isascii() and len(words[gi][0]) <= 6 else "ya",
                          COL.get(color, ORG)]
            wemph[gi] = anim
        d = {"type": sc.get("type", "kinetic"), "a": a, "b": b, "sprite": sc.get("sprite", ""),
             "lines": make_lines([(g, words[g][0]) for g in range(a, b + 1)]) if sc.get("type") != "chat" else []}
        for k in ("counter", "tiles", "rounds", "keyword", "strike"):
            if k in sc:
                v = sc[k]
                if k == "counter":
                    v = {"label": v.get("label", "COUNT"), "from": a + v["from"], "to": a + v["to"], "max": v.get("max", 7)}
                elif k == "tiles":
                    v = {"bad": a + v.get("bad_at", 0), "bad_idx": v.get("bad_idx", 5)}
                elif k == "rounds":
                    v = {"at": [a + x for x in v["at"]], "done": a + v["done"]}
                elif k == "strike":
                    v = {"word": a + v["word"], "at": a + v["at"]}
                d[k] = v
        scenes.append(d)
    return scenes, wstyle, wemph


def font_css():
    css = ""
    for fam, pkg, wt in FONT_FILES:
        f = FONT_DIR / pkg / "files" / f"{pkg}-latin-{wt}-normal.woff2"
        css += f"@font-face{{font-family:'{fam}';src:url('file://{f}');}}\n"
    return css


HTML = r"""<!doctype html><html><head><meta charset="utf-8"><style>
__FONTS__
*{box-sizing:border-box;margin:0;padding:0}
body{width:1080px;height:1920px;overflow:hidden;background:__BG__;position:relative}
#stage{position:absolute;inset:0;overflow:hidden}
.bgglow{position:absolute;left:-200px;right:-200px;bottom:-300px;height:1100px;background:radial-gradient(ellipse at 50% 100%,__DARK__ 0%,rgba(39,16,10,0) 70%)}
.scene{position:absolute;inset:0;display:none}
.lines{position:absolute;left:0;right:0;display:flex;flex-direction:column;align-items:center;gap:6px}
.line{display:flex;gap:26px;align-items:center;justify-content:center;white-space:nowrap}
.w{display:inline-block;line-height:1.18}
.spr{position:absolute;image-rendering:pixelated}
.tile{position:absolute;border:8px solid __GREY__;background:__DARK__}
#mosaic{position:absolute;inset:0;pointer-events:none}
#mosaic div{position:absolute;width:120px;height:120px}
.pb{position:absolute;top:56px;left:60px;right:60px;height:22px;display:flex;gap:6px}
.pb i{flex:1;background:__GREY__;display:block}
.chat{position:absolute;left:60px;right:60px;top:440px;height:1120px;border:8px solid __GREY__;background:#0d0806}
.chat .hd{height:70px;background:__GREY__;color:__CREAM__;font:800 30px 'JB';padding:18px 26px;letter-spacing:3px}
.bub{position:absolute;left:34px;right:34px;top:110px;min-height:560px;padding:26px 30px;font:54px/1.5 'MU';border:6px solid __TEAL__;background:#0d0806;color:__CREAM__}
.scan{position:absolute;inset:0;background:repeating-linear-gradient(0deg,rgba(0,0,0,.16) 0,rgba(0,0,0,.16) 2px,transparent 2px,transparent 5px);mix-blend-mode:multiply;pointer-events:none}
</style></head><body><div id="stage"><div class="bgglow"></div><div class="pb" id="pb"></div>
<div id="scenes"></div><div id="mosaic"></div><div class="scan"></div></div>
<script>
const W=__WORDS__, SC=__SC__, WS=__WS__, WE=__WE__, SPR=__SPR__, PAL=__PAL__, FAM=__FAM__, SS=__SS__, DUR=__DUR__;
const C={ORG:"__ORG__",TEAL:"__TEAL__",CREAM:"__CREAM__",AMB:"__AMB__",GREY:"__GREY__",DARK:"__DARK__"};
function rnd(n){let x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)}
const starts=SC.map((s,i)=>i==0?0:W[s.a][1]-0.04);
function sprite(name,scale){const g=SPR[name],h=g.length,w=g[0].length;let s=`<svg class="spr" width="${w*scale}" height="${h*scale}" viewBox="0 0 ${w} ${h}" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg">`;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const c=g[y][x];if(c!=='.')s+=`<rect x="${x}" y="${y}" width="1.02" height="1.02" fill="${PAL[c]}"/>`}return s+'</svg>'}
function mk(html,parent,style){const e=document.createElement('div');e.style.position='absolute';if(style)e.style.cssText+=style;e.innerHTML=html;parent.appendChild(e);return e}
function place(el,x,y,sc=1,op=1){el.style.transform=`translate(${x}px,${y}px) scale(${sc})`;el.style.opacity=op}
const scEl=document.getElementById('scenes'), scenes=[], X=[];
const LINETOP={kinetic:760,tiles:880,rounds:820,cta:640,chat:0};
const LINEMAX={kinetic:1000,tiles:900,rounds:950,cta:700,chat:0};
SC.forEach((s,si)=>{
  const d=document.createElement('div');d.className='scene';scEl.appendChild(d);scenes.push(d);const x={};X.push(x);
  if(s.type!=='chat'){
    const top=(s.type==='kinetic'&&!s.sprite)?560:LINETOP[s.type];
    let h=`<div class="lines" id="ln${si}" data-max="${LINEMAX[s.type]}" style="top:${top}px">`;
    s.lines.forEach(l=>{h+='<div class="line">'+l[0].map(i=>`<span class="w" id="w${i}" data-f="${Math.round(l[1])}" style="font:400 ${l[1]}px ${FAM[WS[i][0]]};color:${WS[i][1]}">${W[i][0]}</span>`).join('')+'</div>'});
    d.insertAdjacentHTML('beforeend',h+'</div>');
  }
  if(s.sprite){x.spr=mk(sprite(s.sprite,SS[s.sprite]||30),d)}
  if(s.type==='chat'){
    const ch=document.createElement('div');ch.className='chat';
    ch.innerHTML=`<div class="hd">AI CHAT</div><div class="bub" id="bub${si}">${[...Array(s.b-s.a+1).keys()].map(k=>`<span id="pw${s.a+k}" style="display:inline-block;margin-right:14px">${W[s.a+k][0]}</span>`).join('')}</div>
    <div style="position:absolute;left:34px;top:940px;display:flex;gap:16px;align-items:center"><div style="position:relative;width:126px;height:117px">${sprite('robot',9)}</div><div id="aiq${si}" style="font:800 44px 'JB';color:${C.TEAL}">THINKING</div></div>`;
    d.appendChild(ch);x.chat=ch;
    if(s.counter){x.cnt=mk('',d,"left:0;right:0;top:80px;text-align:center;font:800 190px 'JB';color:"+C.ORG+";line-height:1");
      x.cntl=mk(s.counter.label,d,"left:0;right:0;top:300px;text-align:center;font:400 62px 'YA';color:"+C.CREAM)}
  }
  if(s.type==='tiles'){x.tiles=[];for(let k=0;k<10;k++){const t=document.createElement('div');t.className='tile';t.style.cssText+=`left:${60+(k%5)*198}px;top:${230+Math.floor(k/5)*196}px;width:170px;height:170px`;d.appendChild(t);x.tiles.push(t)}}
  if(s.type==='rounds'){x.rt=[];for(let k=0;k<3;k++){const t=document.createElement('div');t.className='tile';t.style.cssText+=`left:${60+k*330}px;top:260px;width:300px;height:360px;border-width:10px`;d.appendChild(t);x.rt.push(t)}}
  if(s.type==='cta'){x.cb=mk('',d,"left:90px;right:90px;top:1380px;height:150px;border:8px solid "+C.TEAL+";background:#0d0806;color:"+C.CREAM+";font:800 62px/134px 'JB';padding-left:34px");
    x.cur=mk(sprite('cursor',18),d)}
});
const pb=document.getElementById('pb');for(let i=0;i<24;i++)pb.appendChild(document.createElement('i'));
const mos=document.getElementById('mosaic'),blocks=[];const MC=[C.ORG,'#B3200F',C.DARK,'#060403',C.ORG,C.AMB];
for(let y=0;y<16;y++)for(let x=0;x<9;x++){const b=document.createElement('div');b.style.left=x*120+'px';b.style.top=y*120+'px';b.style.background=MC[Math.floor(rnd(x*31+y*7)*6)];blocks.push([b,rnd(x*13+y*5+2)]);mos.appendChild(b)}
window.fit=function(){document.querySelectorAll('.lines').forEach(L=>{const sc=L.closest('.scene');const prev=sc.style.display;sc.style.display='block';
  const lines=[...L.children];
  lines.forEach(l=>[...l.children].forEach(w=>w.style.fontSize=w.dataset.f+'px'));
  lines.forEach(l=>{const ws=[...l.children];const tot=ws.reduce((a,c)=>a+c.getBoundingClientRect().width+26,0);if(tot>980){const k=980/tot;ws.forEach(w=>w.style.fontSize=(w.dataset.f*k)+'px')}});
  const mx=parseFloat(L.dataset.max);const hh=L.getBoundingClientRect().height;
  if(hh>mx){const k=mx/hh;lines.forEach(l=>[...l.children].forEach(w=>w.style.fontSize=(parseFloat(w.style.fontSize)*k)+'px'))}
  sc.style.display=prev})};
const step=(t,n)=>Math.floor(t*n)/n;
function draw(t){
  let si=0;for(let i=0;i<SC.length;i++)if(t>=starts[i])si=i;
  scenes.forEach((e,i)=>e.style.display=i==si?'block':'none');
  const s=SC[si],x=X[si],t0=starts[si],loc=t-t0,bob=Math.round(Math.sin(t*6)*1)*8;
  [...pb.children].forEach((e,i)=>e.style.background=(i<(t/DUR)*24)?C.ORG:C.GREY);
  if(s.type!=='chat')for(let i=s.a;i<=s.b;i++){const e=document.getElementById('w'+i);if(!e)continue;
    const a=t-W[i][1];if(a<0){e.style.opacity=0;continue}
    const kind=WE[i]||'in';const k=Math.min(a/0.14,1);let sc=1,dy=0,dx=0,rot=0,sh='none';
    if(kind=='slam'){sc=1+(1-k)*1.2;if(a<0.4){dx=(rnd(Math.floor(a*30)+i)-.5)*14;dy=(rnd(Math.floor(a*30)+i+9)-.5)*14}sh=a<0.25?`-7px 0 ${C.TEAL}, 7px 0 #E8321A`:'none'}
    else if(kind=='glitch'){sc=1+(1-k)*0.5;if(a<0.9){const q=Math.floor(a*20);dx=(rnd(q+i)>0.6?(rnd(q+3)-.5)*30:0);sh=rnd(q+1)>0.5?`-8px 0 ${C.TEAL}, 8px 0 #E8321A`:'none'}}
    else if(kind=='pop'){sc=1+(1-k)*0.45;rot=(1-k)*-4}
    else{sc=1+(1-k)*0.35;dy=(1-k)*40;rot=(rnd(i)-.5)*2}
    sc=Math.round(sc*20)/20;dy=Math.round(dy/4)*4;
    e.style.transform=`translate(${dx}px,${dy}px) scale(${sc}) rotate(${rot}deg)`;e.style.textShadow=sh;e.style.opacity=Math.min(a/0.05,1)}
  if(x.spr){const a=Math.min(loc/0.22,1);const name=s.sprite;const w=SPR[name][0].length*(SS[name]||30);
    place(x.spr,(1080-w)/2,170+bob,Math.round((.45+.55*a)*10)/10)}
  if(s.strike){const e=document.getElementById('w'+s.strike.word);if(e){if(t>=W[s.strike.at][1]){e.style.textDecoration='line-through';e.style.textDecorationColor='#E8321A';e.style.textDecorationThickness='14px'}else e.style.textDecoration='none'}}
  if(s.type==='chat'){
    x.chat.style.opacity=Math.max(0,Math.min((t-W[s.a][1])/0.3,1));
    for(let i=s.a;i<=s.b;i++){document.getElementById('pw'+i).style.opacity=t>=W[i][1]?1:0}
    document.getElementById('aiq'+si).textContent=(t>W[s.b][1]?'ANSWER ME ':'THINKING ')+(Math.floor(t*3)%2?'▌':'');
    if(s.counter){const c=s.counter,t1=W[c.from][1],t2=W[c.to][1];
      const n=t<t1?0:Math.min(c.max,1+Math.floor((t-t1)/Math.max(t2-t1,0.1)*(c.max-0.01)));
      x.cnt.textContent=t<t1?'':n;x.cntl.style.opacity=t<t1?0:1}
  }
  if(s.type==='tiles'){
    for(let k=0;k<10;k++){const a=t-(t0+0.1+k*0.3),tl=x.tiles[k],shown=a>=0;
      const bad=(k==s.tiles.bad_idx)&&t>=W[s.tiles.bad][1];
      tl.style.opacity=shown?1:0;tl.style.background=bad?'#B3200F':(shown?'#5b2a14':C.DARK);tl.style.borderColor=bad?'#E8321A':(shown?C.ORG:C.GREY);
      tl.innerHTML=shown?`<div style="font:800 80px/154px 'JB';text-align:center;color:${bad?C.CREAM:C.AMB}">${bad?'?':'✓'}</div>`:'';
      tl.style.transform=`scale(${a>=0&&a<0.12?1.25:1})`}}
  if(s.type==='rounds'){const ts=s.rounds.at.map(i=>W[i][1]),done=t>=W[s.rounds.done][1];
    x.rt.forEach((tl,k)=>{const a=t-ts[k],on=a>=0;tl.style.opacity=on?1:0.35;tl.style.background=done?C.TEAL2:(on?'#5b2a14':C.DARK);tl.style.borderColor=done?C.TEAL:(on?C.ORG:C.GREY);
      tl.style.transform=`scale(${on&&a<0.12?1.12:1})`;
      tl.innerHTML=`<div style="font:800 40px/60px 'JB';text-align:center;color:${C.CREAM};padding-top:40px">ROUND</div><div style="font:800 170px/200px 'JB';text-align:center;color:${done?C.CREAM:C.AMB}">${k+1}</div>${done?"<div style=\"font:800 60px/60px 'JB';text-align:center;color:#fff\">✓</div>":''}`})}
  if(s.type==='cta'){const kw=s.keyword||'TOPIC';const tp=W[s.b-Math.min(2,s.b-s.a)][1];
    const n=Math.max(0,Math.min(kw.length,Math.floor((t-tp)/0.12)));
    x.cb.textContent='> '+kw.slice(0,n)+(Math.floor(t*3)%2?'_':'');x.cb.style.opacity=t>=W[s.a+Math.floor((s.b-s.a)/2)][1]?1:0;
    place(x.cur,780,1510+bob*0.5,1)}
  blocks.forEach(([b,r])=>{let on=false;for(let q=1;q<starts.length;q++){const Tb=starts[q];if(t>Tb-0.2+0.2*r&&t<Tb+0.02+0.2*r){on=true;break}}b.style.display=on?'block':'none'});
}
window.draw=draw;
</script></body></html>"""


def build_html(scenes, wstyle, wemph, words, dur, out_html):
    rep = {"__FONTS__": font_css(), "__BG__": BG, "__DARK__": DARK, "__GREY__": GREY, "__CREAM__": CREAM,
           "__ORG__": ORG, "__TEAL__": TEAL, "__AMB__": AMB, "__DUR__": str(dur),
           "__WORDS__": json.dumps(words, ensure_ascii=False), "__SC__": json.dumps(scenes),
           "__WS__": json.dumps(wstyle), "__WE__": json.dumps(wemph), "__SPR__": json.dumps(SPR),
           "__PAL__": json.dumps(PAL), "__FAM__": json.dumps(FAM), "__SS__": json.dumps(SPRITE_SCALE)}
    h = HTML
    for k, v in rep.items():
        h = h.replace(k, v)
    Path(out_html).write_text(h, encoding="utf-8")


def render(scenes_spec, words, dur, work, test_times=None, log=print):
    work = Path(work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    scenes, wstyle, wemph = prepare(scenes_spec, words)
    page = work / "page.html"
    build_html(scenes, wstyle, wemph, words, dur, page)
    with sync_playwright() as p:
        br = p.chromium.launch()
        pg = br.new_page(viewport={"width": 1080, "height": 1920})
        pg.goto("file://" + str(page))
        pg.evaluate("document.querySelectorAll('.scene').forEach(e=>e.style.display='block')")
        pg.wait_for_timeout(1500)
        pg.evaluate("fit()")
        pg.wait_for_timeout(300)
        pg.evaluate("fit()")
        if test_times:
            outs = []
            for t in test_times:
                pg.evaluate(f"draw({t})")
                f = work / f"t_{t}.png"
                pg.screenshot(path=str(f))
                outs.append(f)
            br.close()
            return outs
        fr = work / "frames"
        if fr.exists():
            shutil.rmtree(fr)
        fr.mkdir()
        n = int(dur * FPS)
        for i in range(n):
            pg.evaluate(f"draw({i / FPS})")
            pg.screenshot(path=str(fr / f"f_{i:04d}.png"))
            if i % 150 == 0:
                log(f"  frame {i}/{n}")
        br.close()
    out = work / "silent.mp4"
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-framerate", str(FPS), "-i",
                    str(fr / "f_%04d.png"), "-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p", str(out)],
                   check=True)
    shutil.rmtree(fr)
    return out
