#!/usr/bin/env python3
"""One command, whole workflow:  topic -> script -> voice -> timings -> animation -> SFX -> mix -> metadata -> upload.

  python make_short.py "why rereading notes fails"            # full run (uploads as private)
  python make_short.py --queue topics.txt --publish-at auto    # take next unused topic, schedule it
  python make_short.py --spec examples/spec_example.json --voice-mp3 my.mp3 --no-upload   # skip LLM/TTS
Every stage caches into work/<slug>/ so a failed run resumes where it stopped."""
import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def load_env():
    f = ROOT / ".env"
    if f.exists():
        for line in f.read_text().splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"'))


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "short"


def next_topic(queue):
    q = Path(queue)
    done = ROOT / "done_topics.txt"
    used = set(done.read_text().splitlines()) if done.exists() else set()
    for line in q.read_text().splitlines():
        t = line.strip()
        if t and not t.startswith("#") and t not in used:
            return t
    return None


def mark_done(topic):
    with open(ROOT / "done_topics.txt", "a") as f:
        f.write(topic + "\n")


def auto_publish_time(hour_utc=14):
    """Next free daily slot at hour_utc, after any slot used before."""
    f = ROOT / "last_slot.txt"
    base = dt.datetime.now(dt.timezone.utc)
    if f.exists():
        base = max(base, dt.datetime.fromisoformat(f.read_text().strip()))
    slot = (base + dt.timedelta(days=1)).replace(hour=hour_utc, minute=0, second=0, microsecond=0)
    f.write_text(slot.isoformat())
    return slot.strftime("%Y-%m-%dT%H:%M:%SZ")


def probe_dur(p):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)])
    return float(out.strip())


def main():
    load_env()
    ap = argparse.ArgumentParser()
    ap.add_argument("topic", nargs="?")
    ap.add_argument("--queue", help="text file, one topic per line; takes the next unused")
    ap.add_argument("--spec", help="skip the LLM: use this script/scene JSON")
    ap.add_argument("--voice-mp3", help="skip ElevenLabs TTS: use this mp3")
    ap.add_argument("--words", help="skip transcription: use this words.json ([[word,start,end],...])")
    ap.add_argument("--privacy", default="private", choices=["private", "unlisted", "public"])
    ap.add_argument("--publish-at", help="RFC3339 time, or 'auto' = next daily slot (private until then)")
    ap.add_argument("--no-upload", action="store_true")
    ap.add_argument("--count", type=int, default=1, help="how many videos to make from the queue")
    a = ap.parse_args()

    for n in range(a.count):
        topic = a.topic or (next_topic(a.queue) if a.queue else None)
        if not topic and not a.spec:
            sys.exit("Nothing to do: give a topic, a --queue with unused topics, or --spec.")
        run_one(a, topic)
        if a.queue and topic:
            mark_done(topic)
        a.topic = None


def run_one(a, topic):
    from pipeline import llm, voice, render, sfx, mix, thumb
    name = slug(topic or Path(a.spec).stem)
    work = ROOT / "work" / name
    out = ROOT / "out" / name
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    print(f"\n=== {name} ===")

    # 1 script + scene spec + metadata
    sp = work / "spec.json"
    if a.spec:
        shutil.copy(a.spec, sp)
    if not sp.exists():
        print("1/8 writing script (Anthropic API)")
        sp.write_text(json.dumps(llm.make_spec(topic), indent=2, ensure_ascii=False))
    spec = json.loads(sp.read_text())

    # 2 voice
    mp3 = work / "voice.mp3"
    if a.voice_mp3:
        shutil.copy(a.voice_mp3, mp3)
    if not mp3.exists():
        print("2/8 generating voice (ElevenLabs)")
        voice.tts(spec["script"], mp3)

    # 3 word timings
    wj = work / "words.json"
    if a.words:
        shutil.copy(a.words, wj)
    if not wj.exists():
        print("3/8 transcribing for word timings")
        wj.write_text(json.dumps(voice.align(spec["script"], voice.transcribe(mp3))))
    words = json.loads(wj.read_text())
    dur = round(probe_dur(mp3) + 0.5, 2)

    # 4 animation
    silent = work / "silent.mp4"
    if not silent.exists():
        print(f"4/8 rendering animation ({dur}s)")
        render.render(spec["scenes"], words, dur, work)
    # 5 sfx
    scenes, _, wemph = render.prepare(spec["scenes"], words)
    bed = work / "bed.wav"
    print("5/8 building sound effects")
    sfx.make(scenes, wemph, words, dur, bed)
    # 6 mix
    final = out / "final.mp4"
    print("6/8 mixing")
    mix.mix(silent, mp3, bed, dur, final)
    # 7 metadata + thumbnails
    print("7/8 metadata + thumbnails")
    meta = {k: spec[k] for k in ("title", "description", "tags")}
    (out / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    if "thumb" in spec:
        first_sprite = next((s.get("sprite") for s in spec["scenes"] if s.get("sprite")), "robot")
        thumb.make(spec["thumb"], first_sprite, out)
    # 8 upload
    if a.no_upload:
        print(f"8/8 skipped upload. Files in {out}")
        return
    from pipeline import upload
    pa = auto_publish_time() if a.publish_at == "auto" else a.publish_at
    print("8/8 uploading" + (f" (scheduled {pa})" if pa else f" ({a.privacy})"))
    url = upload.upload(final, meta, privacy=a.privacy, publish_at=pa,
                        client_secret=os.environ.get("YT_CLIENT_SECRET", "client_secret.json"))
    (out / "url.txt").write_text(url)
    print("DONE ->", url)


if __name__ == "__main__":
    main()
