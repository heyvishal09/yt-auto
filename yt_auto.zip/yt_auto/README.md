# yt_auto: topic in, finished Short out

`python make_short.py "topic"` runs: **script + scene plan (Claude API) → your cloned voice (ElevenLabs) → word timings →
pixel/kinetic-type animation → SFX → mix → title/description/tags + thumbnails → YouTube upload.**

## Setup (your computer or a server; needs Python 3.10+, Node, ffmpeg)
1. `./setup.sh`, then edit `.env` (Anthropic key, ElevenLabs key + voice id). Use a NEW ElevenLabs key; revoke the one pasted in chat.
2. Google Cloud: enable YouTube Data API v3, create an OAuth *Desktop* client, save as `client_secret.json`.
   First upload opens a browser once; the token is cached in `token.pickle`.
   Unverified API projects can only upload private, so videos go up private (or scheduled-private); publish after a quick look.

## Use
```
python make_short.py "why rereading notes fails"          # one video, uploaded private
python make_short.py --queue topics.txt --count 3          # next 3 unused topics
python make_short.py --queue topics.txt --publish-at auto  # one per day, 14:00 UTC slot
python make_short.py "topic" --no-upload                   # build only -> out/<topic>/
```
Outputs: `out/<topic>/final.mp4, meta.json, thumb_long.png, thumb_short.png, url.txt`. Stages cache in `work/<topic>/`;
delete a file there (e.g. `spec.json`) to redo that stage.

## Test with no API keys
```
python tests/test_pipeline.py
python make_short.py --spec examples/spec_example.json --voice-mp3 examples/voice_example.mp3 --words examples/words_example.json --no-upload
```

## Fully hands-off
Push to a private GitHub repo, add the secrets listed in `.github/workflows/daily.yml` (runs daily 06:30 UTC).
Make `token.pickle` with one local upload, then `base64 -w0 token.pickle` into `YT_TOKEN_B64`.
The uploader sets `containsSyntheticMedia=true` (cloned voice).
