"""Self-check for logic that fails silently. Run: python tests/test_pipeline.py (no API keys needed)."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from pipeline import llm, render, voice

spec = json.load(open(ROOT / "examples/spec_example.json"))
words = json.load(open(ROOT / "examples/words_example.json"))

assert llm.validate(json.loads(json.dumps(spec)))
bad = json.loads(json.dumps(spec))
bad["scenes"][0]["text"] = "wrong words"
try:
    llm.validate(bad)
    raise SystemExit("validate accepted a broken spec")
except ValueError:
    pass

stt = [{"text": w[0], "start": w[1], "end": w[2]} for w in words]
del stt[10]  # transcript lost a word
al = voice.align(spec["script"], stt)
assert len(al) == len(spec["script"].split())
assert all(al[i][1] <= al[i + 1][1] for i in range(len(al) - 1)), "timings went backwards"

scenes, _, _ = render.prepare(spec["scenes"], words)
assert scenes[0]["a"] == 0 and scenes[-1]["b"] == len(words) - 1
assert all(scenes[i]["b"] + 1 == scenes[i + 1]["a"] for i in range(len(scenes) - 1))
print("ok")
